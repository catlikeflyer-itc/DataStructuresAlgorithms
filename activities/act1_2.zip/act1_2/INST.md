Clase de Auto
- int Codigo 
- str Marca
- str Modelo
- int Ano
- float Kilometraje

Clase SUV (Auto)
- str Traccion

Clase Moto (Auto)
- int Cilindraje

Clase Comprador
- str Apellido
- str Nombre
- str INE

Clase Venta // Por comprador
- vector Auto // Add vehicles if buyer buys more
- Comprador

vec Ventas // Vector used to store and search
- Venta 